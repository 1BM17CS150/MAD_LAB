package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    DatabaseHelper myDb;
    EditText e1,e2;
    TextView t1,t2;
    Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DatabaseHelper(this);
        t1 = (TextView)findViewById(R.id.name);
        t2 = (TextView)findViewById(R.id.marks);
        e1 = (EditText) findViewById(R.id.ename);
        e2 = (EditText) findViewById(R.id.emarks);
        b1 = (Button) findViewById(R.id.insert);
        b2 = (Button) findViewById(R.id.display);
        b3 = (Button) findViewById(R.id.update);
        b4 = (Button) findViewById(R.id.delete);
        b1.setOnClickListener((View.OnClickListener) this);
        b2.setOnClickListener((View.OnClickListener) this);
        b3.setOnClickListener((View.OnClickListener) this);
        b4.setOnClickListener((View.OnClickListener) this);
    }
    public void onClick(View v)
    {
        if(v.getId()==R.id.insert)
        {
            myDb.insert_record(e1.getText().toString(),Integer.parseInt(e2.getText().toString()));
            Toast.makeText(this,"Record Inserted",Toast.LENGTH_SHORT).show();
        }else
        if(v.getId()==R.id.display)
        {
            StringBuffer record_details=(StringBuffer) myDb.display_all_records();
            Toast.makeText(this, record_details.toString(), Toast.LENGTH_LONG).show();
        }
        else
        if(v.getId()==R.id.update)
        {
            myDb.update_record(e1.getText().toString(),Integer.parseInt(e2.getText().toString()));
            Toast.makeText(this,"Record Updated",Toast.LENGTH_SHORT).show();
        }
        else
        if(v.getId()==R.id.delete)
        {
            myDb.delete_record(e1.getText().toString());
            Toast.makeText(this,"Record Deleted",Toast.LENGTH_SHORT).show();
        }

    }
}
